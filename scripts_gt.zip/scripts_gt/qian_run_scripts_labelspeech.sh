
python2 qian_gen_lsp_gt_framespeech.py ../lsp_test_106/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py ../lsp_test_library/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py ../lsp_train_106/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py ../lsp_train_301/ -w 8192 -o 4096

echo python2 qian_gen_human_gt_framespeech.py ../human/ -w 8192 -o 4096 
