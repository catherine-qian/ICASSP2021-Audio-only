#!/usr/bin/env python
"""
gen_human_gt_frame.py

Copyright (c) 2018 Idiap Research Institute, http://www.idiap.ch/
Written by Weipeng He <weipeng.he@idiap.ch>
"""
# at vad frames: save all speaker 3d location

import os
import argparse
import cPickle as pickle
import wave
import numpy as np
import math as m


def cart2sph(x, y, z):
    XsqPlusYsq = x ** 2 + y ** 2
    r = m.sqrt(XsqPlusYsq + z ** 2)  # r
    elev = m.atan2(z, m.sqrt(XsqPlusYsq))  # theta
    az = m.atan2(y, x)  # phi
    return az
    # return r, elev, az


import numpy as np

_AUDIO_DIR = 'audio'
_GT_AUDIO_DIR = 'audio_gt'
_GT_VIDEO_DIR = 'video_gt'
_GT_FRAME_DIR = 'gt_frame'

_WAV_SUFFIX = '.wav'
_GT_AUDIO_SUFFIX = '.txt'
_GT_FRAME_PATTERN = '%s.w%d_o%d.gtf.pkl'

_VOICE_TYPE = 1

_NAME_START = 'start'
_NAME_END = 'end'
_NAME_NOISE = 'noise'

_NONSPEECH_SUFFIX = '_n'

_STYPE_NON_SPEECH = 0
_STYPE_SPEECH = 1


def parse_audacity(infile):
    """Load Audacity label VAD annotation file

    Returns:
        (start, end, speakers, segs)
        segs = [(start, end, speaker), ...]
    """
    segs = []
    with open(infile, 'r') as f:
        for l in f:
            s, e, spk = l.strip().split()
            s = float(s)
            e = float(e)
            if spk == _NAME_START:
                start = e
            elif spk == _NAME_END:
                end = s
            else:
                segs.append((s, e, spk))
    speakers = {spk for s, e, spk in segs}
    return (start, end, speakers, segs)


def parse_video_anno(path):
    """Load video annotation

    Returns:
        {name: list of (ts, loc)}
    """
    with open(os.path.join(path, 'id2name'), 'r') as f:
        lines = [l.strip().split() for l in f]
        id2name = {int(i): n for i, n in lines}

    stamps = np.loadtxt(os.path.join(path, 'stamps'))

    video_gt = {n: [] for n in id2name.values()}

    for fid, ts in enumerate(stamps):
        with open(os.path.join(path, 'g%06d.pkl' % fid), 'r') as f:
            id2loc = pickle.load(f)
        for i, loc in id2loc.items():
            video_gt[id2name[i]].append((ts, loc))

    return video_gt


def wav_load_metadata(filename):
    """Load metadata of a wav file instead of reading its content

    Args:
        filename : string or open file handle.

    Returns:
        fs        : sample rate.
        nchannels : number of channels
        nsamples  : number of samples
    """
    w = wave.open(filename, 'rb')
    nchs = w.getnchannels()
    fs = w.getframerate()
    nsamples = w.getnframes()
    w.close()
    return fs, nchs, nsamples


def _to_spkid_stype(name):
    if name == _NAME_NOISE:
        return (_NAME_NOISE, _STYPE_NON_SPEECH)
    elif name.endswith(_NONSPEECH_SUFFIX):
        return (name[:-len(_NONSPEECH_SUFFIX)], _STYPE_NON_SPEECH)
    else:
        return (name, _STYPE_SPEECH)


def _get_speakers_in_frame(start, end, segs):
    spk = []
    for s, e, n in segs:
        if start >= s and end <= e:
            spk.append(_to_spkid_stype(n))
        elif start >= e or end <= s:
            continue
        else:
            return None
    return spk


def query_loc(video_anno, name, ts):
    locs = video_anno[name]

    if ts <= locs[0][0]:
        return locs[0][1]
    elif ts >= locs[-1][0]:
        return locs[-1][1]

    # binary search
    sid = 0
    eid = len(locs)
    while eid - sid > 1:
        mid = (sid + eid) / 2
        if ts >= locs[mid][0]:
            sid = mid
        else:
            eid = mid
    assert eid == sid + 1
    a = ts - locs[sid][0]
    b = locs[eid][0] - ts
    assert a >= 0 and b > 0

    # interpolate
    loc = (a * np.asarray(locs[sid][1]) + b * np.asarray(locs[eid][1])) \
          / (a + b)
    return tuple(loc)


def gen_gtf(audio_anno, video_anno, win_size, hop_size, fs, nsamples):
    onset, _, _, segs = audio_anno

    gtf = []
    # gtf2 = []
    for fid, bsample in enumerate(xrange(0, nsamples - win_size, hop_size)):
        fstart = onset + float(bsample) / fs
        fend = fstart + float(win_size) / fs
        ts = (fstart + fend) / 2.0  # timestamp

        names = video_anno.keys()
        spk = _get_speakers_in_frame(fstart, fend, segs)
        if spk is not None: # with active speaker,
            # gtf2.append((fid, [(query_loc(video_anno, sid, ts), stype, sid) for sid, stype in spk]))
            if spk != []:
                gtf.append((fid, [(query_loc(video_anno, name, ts), int(name in spk[:][0]), name) for name in names]))
                # if len(spk)>=2:
                #     print('here')
            else: # without active speaker
                gtf.append((fid, [(query_loc(video_anno, sid, ts), stype, sid) for sid, stype in spk]))
    return gtf


def process(wav_file, agt_file, vgt_dir, out_file, win_size, hop_size):
    print("here"+agt_file)
    # parse audio annotation

    audio_anno = parse_audacity(agt_file)

    # parse video (speaker trajectory) annotation
    video_anno = parse_video_anno(vgt_dir)

    # check wav length
    fs, nchs, nsamples = wav_load_metadata(wav_file)

    # merge a/v annotation and generate frame-level ground truth
    gtf = gen_gtf(audio_anno, video_anno, win_size, hop_size, fs, nsamples)

    # write to result
    with open(out_file, 'w') as f:
        pickle.dump(gtf, f)
    a = pickle.load(open(out_file, "rb"))
    print(out_file[:-8] + '.txt')

    with open(out_file[:-8] + '.txt', 'w') as fp:
        for x in a:
            if len(x[1]) == 1: # 1 active speaker present in the scene
                fp.write('%s %3.3f %3.3f %3.3f NaN NaN NaN %d %d\n' % (x[0], x[1][0][0][0], x[1][0][0][1], x[1][0][0][2], 1, 0))
            elif len(x[1]) == 2: # 2 target present in the scene, at least one active speaker
                fp.write('%s %3.3f %3.3f %3.3f %3.3f %3.3f %3.3f %d %d\n' % (
                x[0], x[1][0][0][0], x[1][0][0][1], x[1][0][0][2], x[1][1][0][0], x[1][1][0][1], x[1][1][0][2], x[1][0][1], x[1][1][1]))
            else:
                pass


def main(path, win_size, hop_size):
    # for all files
    audiodir = os.path.join(path, _AUDIO_DIR)
    gtadir = os.path.join(path, _GT_AUDIO_DIR)
    gtvdir = os.path.join(path, _GT_VIDEO_DIR)
    outdir = os.path.join(path, _GT_FRAME_DIR)

    for f in os.listdir(audiodir):
        if f.endswith(_WAV_SUFFIX):
            n = f[:-len(_WAV_SUFFIX)]
            if n[0]=='s':
                process(os.path.join(audiodir, f),
                        os.path.join(gtadir, n + _GT_AUDIO_SUFFIX),
                        os.path.join(gtvdir, n),
                        os.path.join(outdir, 'qianspeechall_'+_GT_FRAME_PATTERN %
                                     (n, win_size, hop_size)),
                        win_size, hop_size)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='generate frame-level ground'
                                                 ' truth human talker recordings')
    parser.add_argument('path', metavar='PATH', type=str,
                        help='path to the dataset')
    parser.add_argument('-w', '--window-size', metavar='WIN_SIZE',
                        type=int, required=True, help='analysis window size')
    parser.add_argument('-o', '--hop-size', metavar='HOP_SIZE', type=int,
                        required=True, help='hop size, number of samples between'
                                            ' windows')
    args = parser.parse_args()
    main(args.path, args.window_size, args.hop_size)

# -*- Mode: Python -*-
# vi:si:et:sw=4:sts=4:ts=4

