#!/usr/bin/env python
"""
gen_lsp_gt_frame.py

Copyright (c) 2018 Idiap Research Institute, http://www.idiap.ch/
Written by Weipeng He <weipeng.he@idiap.ch>
"""
# at vad frames: save all speaker 3d location

import sys
import os
import argparse
import cPickle as pickle
import wave

import numpy as np

_AUDIO_DIR = 'audio'
_GT_FILE_DIR = 'gt_file'
_GT_FRAME_DIR = 'gt_frame'

_WAV_SUFFIX = '.wav'
_GT_FILE_SUFFIX = '.gt.pkl'
_GT_FRAME_PATTERN = '%s.w%d_o%d.gtf.pkl'

_VAD_RATE = 100
_VOICE_THRESHOLD = 1.0
_SILENCE_THRESHOLD = 0.0

_VOICE_TYPE = 1

def _file2sid(filepath):
    slpos = filepath.rfind('/') + 1
    dotpos = filepath.rfind('.')
    name = filepath[slpos:dotpos]
    return name

def wav_load_metadata(filename):
    """Load metadata of a wav file instead of reading its content

    Args:
        filename : string or open file handle.

    Returns:
        fs        : sample rate.
        nchannels : number of channels
        nsamples  : number of samples
    """
    w = wave.open(filename, 'rb')
    nchs = w.getnchannels()
    fs = w.getframerate()
    nsamples = w.getnframes()
    w.close()
    return fs, nchs, nsamples

def process(gt_file, wav_file, out_file, phal, win_size, hop_size):
    # parse file-level ground truth
    with open(gt_file, 'r') as f:
        _, _, _, sources = pickle.load(f)

    # check wav length
    fs, nchs, nsamples = wav_load_metadata(wav_file)

    # for each source
    vads = []
    locs = []
    speakers = []
    for loc, src_file, begin, _, _, speaker in sources:
        locs.append(loc)
        speakers.append(speaker)
        
        # vad per sample
        vad = np.zeros(nsamples)
        begin = int(begin * fs)
        v = phal[_file2sid(src_file)] != 1
        v = v.repeat(fs / _VAD_RATE)
        al = min(nsamples - begin, len(v))
        vad[begin:begin+al] = v[:al]

        # vad per frame
        fvad = [np.mean(vad[t:t+win_size]) for t in xrange(0, nsamples - win_size, hop_size)]
        vads.append(fvad) # voice activity for each frame

    # to numpy array
    vads = np.array(vads)

    # for each frame
    gtf = []
    for fid in xrange(vads.shape[1]):
        # only frames with certain vad (either silence or active)
        if np.any(vads[:, fid] >= _VOICE_THRESHOLD):
            gtsrcs = [(locs[sid], vads[sid, fid], speakers[sid]) for sid in range(len(vads[:, fid]))] # save all speaker locations
            gtf.append((fid, gtsrcs)) # only speech frame

    # write to result
    with open(out_file, 'w') as f: # w: write
        # print("with as out_file")
        pickle.dump(gtf, f)
        
    a=pickle.load(open(out_file, "rb" )) # rb: read only
    print(out_file)

    with open(out_file[:-8]+'.txt', 'w') as fp: # write
        for x in a:
            if len(x[1]) == 1: # 1 active speaker present in the scene
                fp.write('%s %3.3f %3.3f %3.3f NaN NaN NaN %d %d\n' % (x[0], x[1][0][0][0], x[1][0][0][1], x[1][0][0][2], 1, 0))
            elif len(x[1]) == 2: # 2 target present in the scene, at least one active speaker
                fp.write('%s %3.3f %3.3f %3.3f %3.3f %3.3f %3.3f %d %d\n' % (
                x[0], x[1][0][0][0], x[1][0][0][1], x[1][0][0][2], x[1][1][0][0], x[1][1][0][1], x[1][1][0][2], x[1][0][1], x[1][1][1]))
            else:
                pass

def main(path, win_size, hop_size, phal_file):
    # load phoneme alignment
    phal = np.load(phal_file)

    # for all files
    audiodir = os.path.join(path, _AUDIO_DIR)
    gtfiledir = os.path.join(path, _GT_FILE_DIR)
    outdir = os.path.join(path, _GT_FRAME_DIR)

    for f in os.listdir(gtfiledir):
        if f.endswith(_GT_FILE_SUFFIX):
            n = f[:-len(_GT_FILE_SUFFIX)]
            process(os.path.join(gtfiledir, f),
                    os.path.join(audiodir, n + _WAV_SUFFIX),
                    os.path.join(outdir,'qianspeechall_'+ _GT_FRAME_PATTERN %
                                            (n, win_size, hop_size)),
                    phal, win_size, hop_size)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='generate frame-level ground'
                                     ' truth for loudspeaker recordings')
    parser.add_argument('path', metavar='PATH', type=str,
                        help='path to the dataset')
    parser.add_argument('-w', '--window-size', metavar='WIN_SIZE',
                        type=int, required=True, help='analysis window size')
    parser.add_argument('-o', '--hop-size', metavar='HOP_SIZE', type=int,
                        required=True, help='hop size, number of samples between'
                        ' windows')
    args = parser.parse_args()
    args.phal_file=os.path.join(os.path.dirname(args.path), '..', 'misc','phone_alignment.npz')

    main(args.path, args.window_size, args.hop_size, args.phal_file)

# -*- Mode: Python -*-
# vi:si:et:sw=4:sts=4:ts=4

