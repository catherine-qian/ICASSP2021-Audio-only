python2 qian_gen_lsp_gt_framespeech.py /home/qian/Documents/dataset/sslr/lsp_test_106/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py /home/qian/Documents/dataset/sslr/lsp_test_library/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py /home/qian/Documents/dataset/sslr/lsp_train_106/ -w 8192 -o 4096

python2 qian_gen_lsp_gt_framespeech.py /home/qian/Documents/dataset/sslr/lsp_train_301/ -w 8192 -o 4096

python2 qian_gen_human_gt_framespeech.py /home/qian/Documents/dataset/sslr/human/ -w 8192 -o 4096

# python2 qian_gen_lsp_gt_framespeech_all.py /home/qian/Documents/dataset/sslr/lsp_test_106/ -w 8192 -o 4096

# python2 qian_gen_lsp_gt_framespeech_all.py /home/qian/Documents/dataset/sslr/lsp_test_library/ -w 8192 -o 4096

# python2 qian_gen_lsp_gt_framespeech_all.py /home/qian/Documents/dataset/sslr/lsp_train_106/ -w 8192 -o 4096

# python2 qian_gen_lsp_gt_framespeech_all.py /home/qian/Documents/dataset/sslr/lsp_train_301/ -w 8192 -o 4096

# python2 qian_gen_human_gt_framespeech_all.py /home/qian/Documents/dataset/sslr/humssan/ -w 8192 -o 4096